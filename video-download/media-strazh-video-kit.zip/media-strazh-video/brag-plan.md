# Brag Plan: МЕДИА.СТРАЖ — Слова имеют вес

## Nine-question planning rubric
1. App: a Russian media text analysis project: source collection plus manual, evidence-based rhetoric review cues.
2. Strongest useful claim: the exact original fragment is highlighted and explained. Not a truth detector; no unmeasured accuracy or live rating claims.
3. Visual hook: an ordinary sentence changes under the project's own cyan highlight, like a line of ink becoming an instrument for reading.
4. Actual UI: analysis.html → Самостоятельная проверка → text → Проанализировать → highlighted words → actual tooltip.
5. Shortest satisfying cut: 25 seconds, allowing a readable 8-second working product scene.
6. Tone: polished + cinematic, an editorial film about language, grounded in the product's existing design.
7. Sound: edited electronic bed, Chronos by Alexander Nakarada (CC0), restrained real CC0 interaction sounds. No voiceover.
8. Share copy: «Слова имеют вес. МЕДИА.СТРАЖ помогает замечать языковые приёмы и проверять контекст. media-strazh.ru»
9. Flow: paste a teaching example → analyse → inspect the exact fragments and explanation. Actual screenshots from the running local app, not invented findings.

## Identity
Background #05070b; panel #0b111a; accent #22d3ee; text #edf3f8; muted #9eacbb. Montserrat 800/700 display, Inter 400/600/700 body. Preserve the source website; scale its UI for the film.

## Format
1080×1920, 30 fps, 25 seconds, 9:16. Russian typography. All important copy between y=160 and y=1610. Final logo/domain hold at least 3 seconds.

## Storyboard
0.0–3.5: «Новость. Или давление?» Giant editorial type; a thin cyan selection runs through the headline. One ordinary phrase, no fabricated outlet attribution.
3.5–8.0: teaching example «Все знают: нас ждёт неминуемая катастрофа. Срочно примите меры.» Highlight «Все знают» and «неминуемая катастрофа» from real native findings; two labels: Обобщение / Запугивание. Give each label time to settle. Small «Учебный пример» label.
8.0–16.5: «Проверьте слова.» Actual manual UI: input → click → analysis highlights → hover explanation. Preserve actual text and explanation. The visual emphasis belongs to the real app.
16.5–20.5: «Сайты СМИ. И Telegram.» Source collection platforms converge into the real automatic filters. No fake counts, invented current news, rating, or 24/7 guarantees.
20.5–25.0: «Замечайте приёмы. Проверяйте контекст.» Actual МЕДИА.СТРАЖ wordmark and media-strazh.ru. Quiet footer «Признаки требуют проверки.» Logo builds from the same highlight line used throughout.

## Sound and edit
Select the musical excerpt after measuring its onsets; align 1–3 major transitions where reading time permits. Copy the selected track into composition/assets/music. Sparse real click/keyboard sounds on their actual gestures. Fade the bed under the final mark, no speech. Measure rendered loudness and true peak; do not claim the mix was auditioned.

## Scope
Create and render locally. The user explicitly requested the final video, so there is no preview approval stop. No deployment, social posting, or project code changes. Freeze the source commit in provenance. No benchmark/holdout access. No personal data in screenshots.
