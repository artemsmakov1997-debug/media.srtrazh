# Hyperframes composition brief — МЕДИА.СТРАЖ

Output: composition/ → ../brag.mp4, 1080×1920, 25 seconds, 30 fps.
Project: /workspace/media.srtrazh, current working tree df1b16f. Read index.html, analysis.html, method.html and README in full through local extraction. Main proof: actual manual highlight/tooltip flow. Brand values and storyboard are in brag-plan.md.

Creative angle: ordinary words have weight; a cyan highlight functions as the transition, the proof and the brand. Large Russian type, precise selection strokes, match cuts into actual UI captures. Dark original panels and Montserrat/Inter. No generic particle field, drifting cards, abstract filler or unsupported statistics. Existing website files are never modified.

Implement with current Hyperframes 0.8.186 native contract, seek-safe GSAP absolute timing, local assets, root duration 25, explicit media timing and ids. The five old domain-skill names referenced by brag have been consolidated in this CLI; use the installed current format, motion, runtimes, look, sound and CLI references. Capture native UI before compositing.

Audio: Chronos / Alexander Nakarada, CC0, file/hash/collection provenance retained. No bundled music with unclear terms. It is an edited library soundtrack, not original music. Real CC0 effect files only. Optional RMS/bass reaction on the highlight stroke, subtle enough to preserve readability; skip if extraction unavailable. Strong cue locks are subordinate to reading holds.

Run lint on the first pass; then check with runtime/layout/contrast, capture and inspect actual frames, render a delivery MP4, decode representative frames, check duration/codec/audio and export a matching poster as first frame. Deliver final MP4, poster and reproducible composition archive locally. User asked for the rendered file, so proceed through rendering without an approval question.
