"""Set the idle poster, normalize audio, and verify the deliverable itself."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parent
first_pass=subprocess.run(['ffmpeg','-hide_banner','-i',str(ROOT/'brag-render.mp4'),'-af',
    'loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json','-f','null','-'],capture_output=True,check=True)
stats_text=first_pass.stderr.decode()
(ROOT/'provenance/audio-first-pass.log').write_text(stats_text)
subprocess.run(['ffmpeg','-v','error','-y','-ss','23','-i',str(ROOT/'brag-render.mp4'),'-frames:v','1',
                '-q:v','2',str(ROOT/'brag.jpg')],check=True)
stats=json.loads(re.findall(r'\{\s*"input_i".*?\}',stats_text,re.S)[-1])
normalizer=('loudnorm=I=-14:TP=-1.5:LRA=9:measured_I='+stats['input_i']+
            ':measured_TP='+stats['input_tp']+':measured_LRA='+stats['input_lra']+
            ':measured_thresh='+stats['input_thresh']+':offset='+stats['target_offset']+
            ':linear=true:print_format=json')
filtergraph="[0:v][1:v]overlay=enable='eq(n,0)':eof_action=pass[v];[0:a]"+normalizer+'[a]'
cmd=['ffmpeg','-hide_banner','-y','-i',str(ROOT/'brag-render.mp4'),'-i',str(ROOT/'brag.jpg'),
     '-filter_complex',filtergraph,'-map','[v]','-map','[a]','-t','25',
     '-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-r','30',
     '-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',
     '-metadata','title=МЕДИА.СТРАЖ — Слова имеют вес',str(ROOT/'brag.mp4')]
with (ROOT/'provenance/final-encode.log').open('w') as f:
    subprocess.run(cmd,stdout=f,stderr=f,check=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries',
    'stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames,duration,pix_fmt:format=duration,size',
    '-of','json',str(ROOT/'brag.mp4')]))
video=next(s for s in probe['streams'] if s['codec_type']=='video')
audio=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (video['codec_name'],video['width'],video['height'],video['r_frame_rate'])==('h264',1080,1920,'30/1')
assert video['nb_frames']=='750' and abs(float(probe['format']['duration'])-25)<.04
assert audio['codec_name']=='aac'
measure=subprocess.run(['ffmpeg','-hide_banner','-i',str(ROOT/'brag.mp4'),'-af',
    'loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json','-f','null','-'],capture_output=True,check=True)
levels=json.loads(re.findall(r'\{\s*"input_i".*?\}',measure.stderr.decode(),re.S)[-1])
assert -17<float(levels['input_i'])<-12
assert float(levels['input_tp'])<-.7
subprocess.run(['ffmpeg','-v','error','-i',str(ROOT/'brag.mp4'),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'brag.mp4'),'-frames:v','1',str(ROOT/'provenance/final-first-frame.png')],check=True)
receipt={'title':'МЕДИА.СТРАЖ — Слова имеют вес','source_commit':'df1b16f80a3bcae30f760426bc5fdd7bd63566b8',
    'hyperframes_version':'0.8.186','hyperframes_check':'passed: zero errors and warnings',
    'duration_seconds':float(probe['format']['duration']),'width':1080,'height':1920,'frames':750,'fps':30,
    'integrated_lufs':float(levels['input_i']),'true_peak_dbTP':float(levels['input_tp']),
    'decoded_without_errors':True,'poster_frame_embedded':True,'file_bytes':(ROOT/'brag.mp4').stat().st_size,
    'sha256':hashlib.sha256((ROOT/'brag.mp4').read_bytes()).hexdigest(),'streams':probe['streams']}
(ROOT/'provenance/verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print(json.dumps(receipt,ensure_ascii=False,indent=2))
