# Credits and provenance

- Product, original interface and logo: МЕДИА.СТРАЖ / artemsmakov1997-debug/media.srtrazh, source commit df1b16f80a3bcae30f760426bc5fdd7bd63566b8. No website source files changed.
- Film concept, typography and composition prepared for this project with the /brag workflow: https://github.com/latent-spaces/brag at 069432cac935ed1895859df201c31436c07fb74e (MIT), rendered with Hyperframes 0.8.186 and FFmpeg.
- Music: Chronos, Alexander Nakarada, CC0 1.0 Universal, FreePD collection via https://github.com/zcxy-dev/fineframe-music/releases/tag/v1 . Source hash and archived FreePD URL retained in provenance/music-source.md. The film uses a 25-second excerpt starting 18 seconds into the source, with fades and loudness adjustment. It is library music, not an original composition.
- SFX: four files distributed with brag, identified in its audio reference as Kenney CC0 sound effects. https://kenney.nl/ . Sparse click, drop, card-slide and soft impact accents.
- Fonts: Inter and Montserrat, Google Fonts, SIL Open Font License. Licence copies in provenance/.
- Browser animation: GSAP 3.14.2, local distribution with original license header; https://gsap.com/standard-license/ .
- On-screen example is explicitly labelled УЧЕБНЫЙ ПРИМЕР. Findings and tooltip are captured from the real manual analyser and saved in provenance/teaching-example-analysis.json. The example is not attributed to a real publisher.
- The film does not claim verified truth, measured accuracy, a live rating, exhaustive coverage or guaranteed uninterrupted collection.
- Music was measured for presence/loudness and aligned using the detected beat grid (120 BPM). No claim of a human listening review is made. An audio-reactive extraction helper was not bundled in this Hyperframes version; typography stays steady, with two measured beat-locked selection/logo reveals.
- Nothing was posted, deployed or uploaded to a public video service.
