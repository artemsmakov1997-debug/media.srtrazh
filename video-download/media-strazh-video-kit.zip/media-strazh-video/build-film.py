"""Build the editable, seek-safe Hyperframes film around authentic UI captures."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'composition'
(OUT / 'compositions').mkdir(exist_ok=True)
fonts = '\n'.join(
    '@font-face{font-family:"%s";font-weight:%s;font-style:normal;src:url("assets/fonts/%s") format("truetype");font-display:block;}'
    % (p.stem.rsplit('-',1)[0].capitalize(),p.stem.rsplit('-',1)[1],p.name)
    for p in (OUT/'assets/fonts').glob('*.ttf')
)

def scene(name, style, content, animation):
    (OUT/'compositions'/f'{name}.html').write_text('''<template>
<style>#root{position:absolute;inset:0;}\n'''+style+'''</style>
<div id="root" data-composition-id="'''+name+'''" data-width="1080" data-height="1920">'''+content+'''</div>
<script>(function(){const tl=gsap.timeline({paused:true});
'''+animation+'''
window.__timelines["'''+name+'''"]=tl;})();</script>
</template>''')

scene('hook', '''
#hook-stage{position:absolute;inset:0;}
#hook-meta{position:absolute;left:76px;top:330px;}
#hook-title{position:absolute;left:70px;top:512px;font:800 142px/1.02 Montserrat;letter-spacing:-8px;}
#hook-subtitle{position:absolute;left:77px;top:693px;font:600 74px/1.16 Montserrat;letter-spacing:-3px;}
#hook-question{position:absolute;left:71px;top:820px;font:800 126px/1.05 Montserrat;letter-spacing:-6px;color:var(--cyan);}
#hook-rule{position:absolute;left:77px;top:1010px;width:915px;height:7px;background:var(--cyan);transform-origin:left;}
#hook-bottom{position:absolute;left:78px;top:1380px;font:500 31px/1.5 Inter;color:var(--muted);}
#hook-caret{position:absolute;left:75px;top:500px;width:7px;height:170px;background:var(--cyan);}
''', '''
<div id="hook-stage">
 <div id="hook-meta" class="eyebrow">СЛОВА ИМЕЮТ ВЕС</div>
 <h1 id="hook-title">Новость.</h1>
 <div id="hook-subtitle">Или</div>
 <div id="hook-question">давление?</div>
 <div id="hook-rule"></div>
 <div id="hook-caret"></div>
 <div id="hook-bottom">Читайте внимательнее.</div>
</div>''', '''
tl.fromTo('#hook-meta',{opacity:0},{opacity:1,duration:.3},0);
tl.fromTo('#hook-title',{opacity:0,filter:'blur(14px)',y:30},{opacity:1,filter:'blur(0px)',y:0,duration:.65,ease:'power4.out'},.08);
tl.fromTo('#hook-caret',{opacity:0,x:0},{opacity:1,x:815,duration:.85,ease:'power2.inOut'},.25);
tl.to('#hook-caret',{opacity:0,duration:.15},1.1);
tl.fromTo('#hook-subtitle',{opacity:0},{opacity:1,duration:.25},1.18);
tl.fromTo('#hook-question',{opacity:0,filter:'blur(16px)'},{opacity:1,filter:'blur(0px)',duration:.55,ease:'power4.out'},1.38);
tl.fromTo('#hook-rule',{scaleX:0},{scaleX:1,duration:.7,ease:'expo.out'},1.6);
tl.fromTo('#hook-bottom',{opacity:0},{opacity:1,duration:.4},2.05);
tl.to('#hook-stage',{y:-150,opacity:0,filter:'blur(12px)',duration:.45,ease:'power3.in'},3.05);
''')

scene('words', '''
#words-stage{position:absolute;inset:0;}
#words-meta{position:absolute;left:78px;top:295px;}
#words-quote{position:absolute;left:76px;top:490px;font:700 85px/1.28 Montserrat;letter-spacing:-3px;}
#words-quote .phrase{display:inline-block;position:relative;isolation:isolate;padding:4px 13px 9px 9px;margin-left:-9px;}
.word-fill{position:absolute;inset:0;z-index:0;background:var(--cyan);transform-origin:left;border-radius:8px;}
.word-text{position:relative;z-index:1;font-weight:inherit;}
#words-general{position:absolute;left:80px;top:1160px;}
#words-fear{position:absolute;left:535px;top:1160px;}
.technique{padding:20px 24px;border:2px solid var(--cyan);border-radius:14px;font:700 31px/1.1 Inter;color:var(--cyan);background:#0b1720;}
#words-note{position:absolute;left:80px;top:1400px;font:500 33px/1.45 Inter;color:var(--muted);}
#words-line{position:absolute;left:78px;top:1330px;width:920px;height:3px;background:#304153;transform-origin:left;}
''', '''
<div id="words-stage">
 <div id="words-meta" class="eyebrow">УЧЕБНЫЙ ПРИМЕР</div>
 <div id="words-quote"><span id="phrase-one" class="phrase"><i id="fill-one" class="word-fill"></i><b class="word-text">Все знают:</b></span><br><span>нас ждёт</span><br><span id="phrase-two" class="phrase"><i id="fill-two" class="word-fill"></i><b class="word-text">неминуемая</b></span><br><span id="phrase-three" class="phrase"><i id="fill-three" class="word-fill"></i><b class="word-text">катастрофа.</b></span></div>
 <div id="words-general" class="technique">Обобщение</div>
 <div id="words-fear" class="technique">Запугивание</div>
 <div id="words-line"></div>
 <div id="words-note">Знакомые слова.<br>Повод проверить контекст.</div>
</div>''', '''
tl.fromTo('#words-meta',{opacity:0},{opacity:1,duration:.3},.1);
tl.fromTo('#words-quote',{opacity:0,y:95,filter:'blur(10px)'},{opacity:1,y:0,filter:'blur(0px)',duration:.65,ease:'expo.out'},.02);
// beat-locked: first selection starts at film time 4.305, a measured 120 BPM beat.
tl.fromTo('#fill-one',{scaleX:0},{scaleX:1,duration:.45,ease:'power2.inOut'},.805);
tl.to('#phrase-one',{color:'#041116',duration:.2},.92);
tl.fromTo('#words-general',{opacity:0,y:18},{opacity:1,y:0,duration:.4,ease:'power4.out'},1.05);
tl.fromTo('#fill-two',{scaleX:0},{scaleX:1,duration:.45,ease:'power2.inOut'},1.72);
tl.fromTo('#fill-three',{scaleX:0},{scaleX:1,duration:.45,ease:'power2.inOut'},1.85);
tl.to(['#phrase-two','#phrase-three'],{color:'#041116',duration:.2},2.03);
tl.fromTo('#words-fear',{opacity:0,y:18},{opacity:1,y:0,duration:.4,ease:'power4.out'},2.12);
tl.fromTo('#words-line',{scaleX:0},{scaleX:1,duration:.8,ease:'power3.out'},2.3);
tl.fromTo('#words-note',{opacity:0},{opacity:1,duration:.4},2.55);
tl.to('#words-stage',{opacity:0,x:-180,filter:'blur(12px)',duration:.4,ease:'power3.in'},4.1);
''')

scene('demo', '''
#demo-heading{position:absolute;left:76px;top:218px;font:800 78px/1.1 Montserrat;letter-spacing:-3.2px;}
#demo-heading span{color:var(--cyan);}
#demo-input-frame{position:absolute;left:160px;top:390px;width:760px;height:1282px;border-radius:26px;overflow:hidden;box-shadow:0 24px 85px #0008;}
#demo-input-image{width:760px;height:auto;display:block;}
#demo-result-frame{position:absolute;left:86px;top:474px;width:908px;height:805px;border-radius:26px;overflow:hidden;box-shadow:0 24px 85px #0008;}
#demo-result-image{width:908px;height:auto;display:block;}
#demo-tooltip-frame{position:absolute;left:102px;top:1335px;width:876px;height:230px;}
#demo-tooltip-image{display:block;width:876px;height:228.3px;}
#demo-cursor{position:absolute;left:770px;top:1280px;width:54px;height:75px;z-index:4;filter:drop-shadow(0px 4px 10px #000);}
#demo-state{position:absolute;left:78px;top:1640px;font:500 28px/1.4 Inter;color:var(--muted);}
''', '''
<h2 id="demo-heading">Проверьте<br><span>слова.</span></h2>
<div id="demo-input-frame"><img id="demo-input-image" class="clip" data-start="0" data-duration="8.5" data-track-index="1" src="assets/ui/input.png" alt="Настоящая форма самостоятельной проверки"></div>
<div id="demo-result-frame" data-layout-allow-overflow><img id="demo-result-image" class="clip" data-start="0" data-duration="8.5" data-track-index="2" src="assets/ui/result.png" alt="Результат реального анализа учебного текста"></div>
<div id="demo-tooltip-frame"><img id="demo-tooltip-image" class="clip" data-start="0" data-duration="8.5" data-track-index="3" src="assets/ui/tooltip.png" alt="Настоящее объяснение обобщения"></div>
<svg id="demo-cursor" viewBox="0 0 40 56" aria-hidden="true"><path d="M4 3L33 30L21 32L27 48L19 52L13 35L4 43Z" fill="#edf3f8" stroke="#05070b" stroke-width="3"/></svg>
<div id="demo-state">УЧЕБНЫЙ ПРИМЕР · РЕАЛЬНЫЙ РЕЗУЛЬТАТ</div>
''', '''
tl.fromTo('#demo-heading',{opacity:0,filter:'blur(8px)'},{opacity:1,filter:'blur(0px)',duration:.45},.05);
tl.fromTo('#demo-input-frame',{opacity:0,y:100,scale:.92},{opacity:1,y:0,scale:1,duration:.7,ease:'expo.out'},.1);
tl.fromTo('#demo-state',{opacity:0},{opacity:1,duration:.4},.5);
tl.fromTo('#demo-cursor',{opacity:0,x:0,y:0},{opacity:1,x:0,y:0,duration:.15},.7);
tl.to('#demo-cursor',{x:-340,y:145,duration:.9,ease:'power2.inOut'},.85);
tl.to('#demo-cursor',{scale:.83,duration:.11,ease:'power2.in'},1.85);
tl.to('#demo-cursor',{scale:1,duration:.2,ease:'power4.out'},1.96);
tl.to('#demo-input-frame',{opacity:0,scale:1.06,filter:'blur(6px)',duration:.3,ease:'power2.in'},2.2);
tl.fromTo('#demo-result-frame',{opacity:0,y:65,scale:.94},{opacity:1,y:0,scale:1,filter:'blur(0px)',duration:.65,ease:'expo.out'},2.2);
tl.to('#demo-cursor',{x:-465,y:-590,duration:1,ease:'power2.inOut'},2.65);
tl.fromTo('#demo-tooltip-frame',{opacity:0,y:26},{opacity:1,y:0,duration:.4,ease:'power4.out'},3.85);
tl.to('#demo-cursor',{opacity:0,duration:.3},4.1);
tl.to(['#demo-result-frame','#demo-tooltip-frame','#demo-heading','#demo-state'],{opacity:0,filter:'blur(10px)',duration:.4},8.1);
''')

scene('sources', '''
#sources-heading{position:absolute;left:75px;top:290px;font:800 86px/1.15 Montserrat;letter-spacing:-3.8px;}
#sources-heading span{color:var(--cyan);}
#source-web,#source-tg{position:absolute;top:620px;width:426px;padding:29px 24px;border:2px solid #304153;background:#0e1722;border-radius:20px;text-align:center;}
#source-web{left:78px;}#source-tg{left:576px;}
.source-name{font:700 34px/1.2 Inter;}
.source-small{margin-top:17px;color:var(--muted);font:400 28px/1.4 Inter;}
#source-link{position:absolute;left:76px;top:780px;width:926px;height:260px;overflow:visible;}
#source-output{position:absolute;left:78px;top:1040px;width:924px;border:2px solid var(--cyan);border-radius:22px;background:#0b1720;padding:30px 20px;text-align:center;font:700 42px/1.2 Montserrat;color:var(--cyan);}
#source-caption{position:absolute;left:82px;top:1280px;font:500 37px/1.4 Inter;}
#source-note{position:absolute;left:82px;top:1460px;font:400 28px/1.4 Inter;color:var(--muted);}
''', '''
<h2 id="sources-heading">Сайты СМИ.<br><span>И Telegram.</span></h2>
<div id="source-web"><div class="source-name">Сайты изданий</div><div class="source-small">Публикации</div></div>
<div id="source-tg"><div class="source-name">Telegram</div><div class="source-small">Сообщения каналов</div></div>
<svg id="source-link" data-layout-allow-overflow viewBox="0 0 926 260" aria-hidden="true"><path d="M212 0V90Q212 130 252 130H423Q463 130 463 170V260" fill="none" stroke="#22d3ee" stroke-width="4"/><path d="M712 0V90Q712 130 672 130H503Q463 130 463 170V260" fill="none" stroke="#22d3ee" stroke-width="4"/><circle id="source-dot-a" cx="212" cy="0" r="8" fill="#edf3f8"/><circle id="source-dot-b" cx="712" cy="0" r="8" fill="#edf3f8"/></svg>
<div id="source-output">Автоматический анализ</div>
<div id="source-caption">Одна подборка.<br>Фрагменты для проверки.</div>
<div id="source-note">Сбор из открытых источников</div>
''', '''
tl.fromTo('#sources-heading',{opacity:0,y:35},{opacity:1,y:0,duration:.5,ease:'expo.out'},.05);
tl.fromTo('#source-web',{opacity:0,x:-60},{opacity:1,x:0,duration:.5,ease:'power4.out'},.35);
tl.fromTo('#source-tg',{opacity:0,x:60},{opacity:1,x:0,duration:.5,ease:'power4.out'},.65);
tl.fromTo('#source-link',{opacity:0},{opacity:1,duration:.4},1.55);
tl.to('#source-dot-a',{attr:{cx:463,cy:250},duration:.85,ease:'power2.inOut'},1.65);
tl.to('#source-dot-b',{attr:{cx:463,cy:250},duration:.85,ease:'power2.inOut'},1.65);
tl.fromTo('#source-output',{opacity:0,y:20},{opacity:1,y:0,duration:.5,ease:'power4.out'},1.55);
tl.fromTo('#source-caption',{opacity:0},{opacity:1,duration:.4},1.95);
tl.fromTo('#source-note',{opacity:0},{opacity:1,duration:.4},1.95);
tl.to(['#sources-heading','#source-web','#source-tg','#source-link','#source-output','#source-caption','#source-note'],{opacity:0,filter:'blur(9px)',duration:.4},3.6);
''')

scene('outro', '''
#outro-logo{position:absolute;left:355px;top:320px;width:370px;height:370px;}
#outro-logo-image{width:370px;height:370px;display:block;}
#outro-brand{position:absolute;left:70px;top:735px;width:940px;text-align:center;font:800 74px/1.1 Montserrat;letter-spacing:-2.8px;color:var(--cyan);}
#outro-message{position:absolute;left:74px;top:975px;width:932px;font:700 64px/1.35 Montserrat;letter-spacing:-2px;text-align:center;}
#outro-domain{position:absolute;left:160px;top:1265px;width:760px;text-align:center;padding:30px 20px;border-radius:16px;background:var(--cyan);color:#041116;font:700 52px/1.05 Inter;}
#outro-note{position:absolute;left:80px;top:1515px;width:920px;text-align:center;font:400 29px/1.4 Inter;color:var(--muted);}
''', '''
<div id="outro-logo"><img id="outro-logo-image" class="clip" data-start="0" data-duration="4.5" data-track-index="1" src="assets/logo.png" alt="Логотип МЕДИА.СТРАЖ"></div>
<div id="outro-brand">МЕДИА.СТРАЖ</div>
<div id="outro-message">Замечайте приёмы.<br>Проверяйте контекст.</div>
<div id="outro-domain">media-strazh.ru</div>
<div id="outro-note">Признаки требуют проверки.</div>
''', '''
// beat-locked: the final mark starts on the measured musical beat at film time 20.795 s.
tl.fromTo('#outro-logo',{opacity:0,scale:.72,filter:'blur(12px)'},{opacity:1,scale:1,filter:'blur(0px)',duration:.65,ease:'expo.out'},.295);
tl.fromTo('#outro-brand',{opacity:0,filter:'blur(9px)'},{opacity:1,filter:'blur(0px)',duration:.45},.25);
tl.fromTo('#outro-message',{opacity:0},{opacity:1,duration:.4},.65);
tl.fromTo('#outro-domain',{opacity:0,y:22},{opacity:1,y:0,duration:.45,ease:'power4.out'},.85);
tl.fromTo('#outro-note',{opacity:0},{opacity:1,duration:.45},1.05);
''')

hosts = [('hook',0,3.5),('words',3.5,4.5),('demo',8,8.5),('sources',16.5,4),('outro',20.5,4.5)]
host_html='\n'.join(f'<div id="{n}" class="clip" data-composition-id="{n}" data-composition-src="compositions/{n}.html" data-start="{s}" data-duration="{d}" data-track-index="1" data-width="1080" data-height="1920"></div>' for n,s,d in hosts)
audio_html='''<audio id="music-bed" class="clip" data-start="0" data-duration="25" data-track-index="10" data-timeline-role="music" data-volume="1" src="assets/music/soundtrack.wav"></audio>'''
for track,(n,t,src,gain,d) in enumerate([('highlight',4.305,'drop_001.ogg',.18,.7),('fear',5.4,'drop_001.ogg',.16,.7),('button',9.96,'click_001.ogg',.4,.3),('reveal',10.2,'card-slide-1.ogg',.15,1.1),('tooltip',11.86,'click_001.ogg',.2,.3),('logo',20.81,'impactSoft_medium_000.ogg',.2,1.5)],11):
    d=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(OUT/'assets/sfx'/src)]))
    audio_html+=f'\n<audio id="sfx-{n}" class="clip" data-start="{t}" data-duration="{d}" data-track-index="{track}" data-volume="{gain}" src="assets/sfx/{src}"></audio>'
root_html='''<!doctype html><html lang="ru" data-resolution="portrait" data-composition-variables='[{"id":"color-ground","type":"color","label":"Фон","default":"#05070b"},{"id":"color-accent","type":"color","label":"Акцент","default":"#22d3ee"}]'>
<head><meta charset="utf-8"><meta name="viewport" content="width=1080,height=1920"><title>МЕДИА.СТРАЖ — Слова имеют вес</title><script src="assets/gsap.min.js"></script><style>
'''+fonts+'''
:root{--ground:#05070b;--ink:#edf3f8;--cyan:#22d3ee;--muted:#9eacbb;}
*{box-sizing:border-box;margin:0;padding:0;}html,body{width:1080px;height:1920px;overflow:hidden;background:var(--ground);color:var(--ink);font-family:Inter;}
#root{position:relative;width:100%;height:100%;}#ground{position:absolute;inset:0;background:#05070b;}
.eyebrow{font:700 30px/1.2 Inter;letter-spacing:4px;color:var(--cyan);}
#film-brand{position:absolute;left:76px;top:115px;font:800 28px/1 Montserrat;letter-spacing:1.4px;color:var(--cyan);z-index:20;}
#film-line{position:absolute;left:78px;top:1730px;width:924px;height:3px;background:#202d3b;z-index:20;}
#progress-fill{width:924px;height:3px;background:var(--cyan);transform-origin:left;}
#film-footer{position:absolute;left:78px;top:1768px;font:500 28px/1.4 Inter;letter-spacing:3px;color:var(--muted);z-index:20;}
</style></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="25" data-width="1080" data-height="1920">
<div id="ground"></div>'''+host_html+'''
<div id="film-brand">МЕДИА.СТРАЖ</div><div id="film-line"><div id="progress-fill"></div></div><div id="film-footer">СЛОВА ИМЕЮТ ВЕС</div>
'''+audio_html+'''</div><script>
(function(){const tl=gsap.timeline({paused:true});tl.fromTo('#progress-fill',{scaleX:0},{scaleX:1,duration:25,ease:'none'},0);tl.to(['#film-brand','#film-footer'],{opacity:0,duration:.4},20.4);window.__timelines=window.__timelines||{};window.__timelines['main']=tl;})();
</script></body></html>'''
(OUT/'index.html').write_text(root_html)
(OUT/'index.motion.json').write_text(json.dumps({'duration':25,'assertions':[
    {'kind':'appearsBy','selector':'#hook-title','bySec':.9},
    {'kind':'appearsBy','selector':'#outro-domain','bySec':22},
    {'kind':'staysInFrame','selector':'#outro-domain'},
]},indent=2))
print('Five native Hyperframes scenes authored; root duration 25 seconds')
