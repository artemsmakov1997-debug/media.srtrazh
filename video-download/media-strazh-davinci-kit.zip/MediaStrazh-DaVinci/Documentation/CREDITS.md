# Источники комплекта для DaVinci

Логотип и снимки рабочего интерфейса: проект МЕДИА.СТРАЖ,
artemsmakov1997-debug/media.srtrazh, исходная версия df1b16f.

Музыка: Chronos — Alexander Nakarada, CC0 1.0 Universal, коллекция FreePD.
Использован фрагмент 18–43 с; сведения об источнике и контрольная сумма
сохранены в `music-source.md`. Это библиотечная композиция.

Эффекты: Kenney CC0, поставка brag на коммите
069432cac935ed1895859df201c31436c07fb74e, https://github.com/latent-spaces/brag.

Шрифты: Inter и Montserrat, SIL Open Font License. Тексты лицензий рядом:
`font-inter-OFL.txt` и `font-montserrat-OFL.txt`.

Исходный ролик был собран с Hyperframes 0.8.186 / GSAP 3.14.2 / FFmpeg.
В этом комплекте браузерный движок для монтажа не нужен: видеоподложки уже
отрендерены; титры представлены отдельно в FCPXML и шаблонах Fusion.

Формат FCPXML сверялся с DTD Apple 1.10 из CommandPost:
https://github.com/CommandPost/CommandPost/tree/develop/src/extensions/cp/apple/fcpxml/dtd.
Для проверки совместимости представления титров изучено публичное описание
Basic Title в https://github.com/hermann-ndamen/resolve-captions-fcpxml.
Генератор комплекта и шаблоны написаны для данного проекта; внешние скрипты
из этих репозиториев не исполнялись и не включены в комплект.

Пример анализа — учебный, это явно написано в ролике. Он не представляет
измеренную точность системы или независимую проверку публикаций СМИ.
